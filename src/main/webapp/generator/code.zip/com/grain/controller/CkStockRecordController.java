package com.grain.controller;

/**
 * 
 *
 * @author lpy
 * @date 2019-11-07 19:44:55
 */

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.stereotype.Controller;

import com.grain.entity.CkStockRecordEntity;
import com.grain.service.CkStockRecordService;
import com.grain.utils.PageUtils;
import com.grain.utils.R;


@Controller
@RequestMapping("ckstockrecord")
public class CkStockRecordController {
	@Autowired
	private CkStockRecordService ckStockRecordService;
	
	@RequestMapping("/ckstockrecord.html")
	public String list(){
		return "ckstockrecord/ckstockrecord.html";
	}
	
	@RequestMapping("/ckstockrecord_add.html")
	public String add(){
		return "ckstockrecord/ckstockrecord_add.html";
	}
	
	/**
	 * 列表
	 */
	@ResponseBody
	@RequestMapping("/list")
	@RequiresPermissions("ckstockrecord:list")
	public R list(Integer page, Integer limit){
		Map<String, Object> map = new HashMap<>();
		map.put("offset", (page - 1) * limit);
		map.put("limit", limit);
		
		//查询列表数据
		List<CkStockRecordEntity> ckStockRecordList = ckStockRecordService.queryList(map);
		int total = ckStockRecordService.queryTotal(map);
		
		PageUtils pageUtil = new PageUtils(ckStockRecordList, total, limit, page);
		
		return R.ok().put("page", pageUtil);
	}
	
	
	/**
	 * 信息
	 */
	@ResponseBody
	@RequestMapping("/info/{stockRecordId}")
	@RequiresPermissions("ckstockrecord:info")
	public R info(@PathVariable("stockRecordId") Integer stockRecordId){
		CkStockRecordEntity ckStockRecord = ckStockRecordService.queryObject(stockRecordId);
		
		return R.ok().put("ckStockRecord", ckStockRecord);
	}
	
	/**
	 * 保存
	 */
	@ResponseBody
	@RequestMapping("/save")
	@RequiresPermissions("ckstockrecord:save")
	public R save(@RequestBody CkStockRecordEntity ckStockRecord){
		ckStockRecordService.save(ckStockRecord);
		
		return R.ok();
	}
	
	/**
	 * 修改
	 */
	@ResponseBody
	@RequestMapping("/update")
	@RequiresPermissions("ckstockrecord:update")
	public R update(@RequestBody CkStockRecordEntity ckStockRecord){
		ckStockRecordService.update(ckStockRecord);
		
		return R.ok();
	}
	
	/**
	 * 删除
	 */
	@ResponseBody
	@RequestMapping("/delete")
	@RequiresPermissions("ckstockrecord:delete")
	public R delete(@RequestBody Integer[] stockRecordIds){
		ckStockRecordService.deleteBatch(stockRecordIds);
		
		return R.ok();
	}
	
}
