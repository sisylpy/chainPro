$(function () {
    $("#jqGrid").jqGrid({
        url: '../ckstockrecord/list',
        datatype: "json",
        colModel: [			
			{ label: 'stockRecordId', name: 'stockRecordId', width: 50, key: true },
			{ label: '申请id', name: 'stApplyId', width: 80 }, 			
			{ label: '出库数量', name: 'quantity', width: 80 }, 			
			{ label: '出库时间', name: 'outTime', width: 80 }, 			
			{ label: '拣货人员', name: 'pickUserId', width: 80 }, 			
			{ label: '检查人员', name: 'checkUserId', width: 80 }, 			
			{ label: '录入人员', name: 'enterUserId', width: 80 }			
        ],
		viewrecords: true,
        height: 400,
        rowNum: 10,
		rowList : [10,30,50],
        rownumbers: true, 
        rownumWidth: 25, 
        autowidth:true,
        multiselect: true,
        pager: "#jqGridPager",
        jsonReader : {
            root: "page.list",
            page: "page.currPage",
            total: "page.totalPage",
            records: "page.totalCount"
        },
        prmNames : {
            page:"page", 
            rows:"limit", 
            order: "order"
        },
        gridComplete:function(){
        	//隐藏grid底部滚动条
        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
        }
    });
});

var vm = new Vue({
	el:'#rrapp',
	data:{
		
	},
	methods: {
		update: function (event) {
			var stockRecordId = getSelectedRow();
			if(stockRecordId == null){
				return ;
			}
			
			location.href = "ckstockrecord_add.html?stockRecordId="+stockRecordId;
		},
		del: function (event) {
			var stockRecordIds = getSelectedRows();
			if(stockRecordIds == null){
				return ;
			}
			
			confirm('确定要删除选中的记录？', function(){
				$.ajax({
					type: "POST",
				    url: "../ckstockrecord/delete",
				    data: JSON.stringify(stockRecordIds),
				    success: function(r){
						if(r.code == 0){
							alert('操作成功', function(index){
								$("#jqGrid").trigger("reloadGrid");
							});
						}else{
							alert(r.msg);
						}
					}
				});
			});
		}
	}
});