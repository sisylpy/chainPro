var stockRecordId = T.p("stockRecordId");
var vm = new Vue({
	el:'#rrapp',
	data:{
		title:"新增",
		ckStockRecord:{}
	},
	created: function() {
		if(stockRecordId != null){
			this.title = "修改";
			this.getInfo(stockRecordId)
		}
    },
	methods: {
		getInfo: function(stockRecordId){
			$.get("../ckstockrecord/info/"+stockRecordId, function(r){
                vm.ckStockRecord = r.ckStockRecord;
            });
		},
		saveOrUpdate: function (event) {
			var url = vm.ckStockRecord.stockRecordId == null ? "../ckstockrecord/save" : "../ckstockrecord/update";
			$.ajax({
				type: "POST",
			    url: url,
			    data: JSON.stringify(vm.ckStockRecord),
			    success: function(r){
			    	if(r.code === 0){
						alert('操作成功', function(index){
							vm.back();
						});
					}else{
						alert(r.msg);
					}
				}
			});
		},
		back: function (event) {
			history.go(-1);
		}
	}
});